% 数据标准化
X = normalize(X);  % 或者 X = (X - mean(X)) ./ std(X);

% K-means 聚类函数
function [centers, labels, accuracies] = kmeans(X, y, K, max_iters, tol)
    [num_samples, num_features] = size(X);
    centers = kmeansPlusPlus(X, K); % 使用 K-means++ 初始化簇心
    prev_centers = zeros(K, num_features);
    accuracies = [];
    
    for iter = 1:max_iters
        % 计算每个样本点与簇心的距离
        distances = pdist2(X, centers);
        [~, labels] = min(distances, [], 2);
        
        % 重新计算每个簇的中心
        for k = 1:K
            centers(k, :) = mean(X(labels == k, :), 1);
        end
        
        % 计算分类正确率（标签映射）
        accuracy = calculate_accuracy(labels, y, K);
        accuracies = [accuracies, accuracy];
        
        % 检查簇心是否收敛
        if max(abs(centers - prev_centers), [], 'all') < tol
            fprintf('Converged after %d iterations.\n', iter);
            break;
        end
        
        prev_centers = centers;
    end
end

% 标签映射函数
function accuracy = calculate_accuracy(labels, y, K)
    accuracy = 0;
    for k = 1:K
        cluster_labels = y(labels == k);
        most_common_label = mode(cluster_labels);
        accuracy = accuracy + sum(cluster_labels == most_common_label);
    end
    accuracy = accuracy / length(y);
end

% K-means++ 初始化函数
function centers = kmeansPlusPlus(X, K)
    [num_samples, ~] = size(X);
    centers = zeros(K, size(X, 2));
    centers(1, :) = X(randi(num_samples), :);
    for k = 2:K
        dist = pdist2(X, centers(1:k-1, :));
        min_dist = min(dist, [], 2);
        prob = min_dist.^2 / sum(min_dist.^2);
        idx = find(rand <= cumsum(prob), 1); 
        centers(k, :) = X(idx, :);
    end
end

% 运行 K-means 算法
K = 20;
[centers, labels, accuracies] = kmeans(X, y, K, 200, 1e-6);

% 绘制准确率变化曲线
figure;
plot(accuracies);
xlabel('Iterations');
ylabel('Accuracy');
title('K-means Clustering Accuracy per Iteration');

% 输出最终的簇心
disp('Final cluster centers:');
disp(centers);